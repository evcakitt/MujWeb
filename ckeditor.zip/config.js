/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/



// ckeditor/config.js
CKEDITOR.editorConfig = function(config) {
   config.filebrowserBrowseUrl = '../kcfinder/browse.php?type=files';
   config.filebrowserImageBrowseUrl = '../kcfinder/browse.php?type=images';
   config.filebrowserFlashBrowseUrl = '../kcfinder/browse.php?type=flash';
   config.filebrowserUploadUrl = './kcfinder/upload.php?type=files';
   config.filebrowserImageUploadUrl = './kcfinder/upload.php?type=images';
   config.filebrowserFlashUploadUrl = './kcfinder/upload.php?type=flash';
   config.height = '800px';
   config.width = 'auto';
   config.uiColor = '#FDD7FC'; 
   
   
   config.toolbar = 'MyToolbar';
 
	config.toolbar_MyToolbar =
	[
		// JavaScript Document

{ name: 'document', items : [ 'Source','-' ] },
	{ name: 'clipboard', items : [ 'Cut','Copy','Paste','PasteText','PasteFromWord','-','Undo','Redo' ] },
	{ name: 'editing', items : [ 'Find','-','SpellChecker', 'Scayt' ] },
  	{ name: 'insert', items : [ 'Image','-','Link','Unlink','Anchor','-','Table','Smiley','SpecialChar' ] },
	
	'/',
	{ name: 'basicstyles', items : [ 'Bold','Italic','Underline','Strike','Subscript','Superscript','-' ] },
	{ name: 'paragraph', items : [ 'NumberedList','BulletedList','-','Outdent','Indent','-',
	'-','JustifyLeft','JustifyCenter','JustifyRight','JustifyBlock','ShowBlocks','-','About','Save', ] },
	 

	'/', 
	{ name: 'styles', items : [ 'Styles','Format','Font','FontSize' ] },
	{ name: 'colors', items : [ 'TextColor','BGColor' ] },
	 
	];
   
    
   
};

 
document.write("ahoj");
  


  

  